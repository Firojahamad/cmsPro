For configure -
Step 1:

install all package using this command-
cd rudimentary-cms
npm init -y
npm i express body-parser mysql2
or (alternative)
npm i 

Step2:
define schema of mysql database command-
open command line myql or what you have 

Schema-

CREATE DATABASE simple_cms2;

USE simple_cms2;

CREATE TABLE entities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  mobile_number VARCHAR(20) NOT NULL,
  date_of_birth DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



Step3:
Server.js
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123456', // Replace with your MySQL password
  database: 'simple_cms2'
});

Step4:
type command - node Server 
then open localhost:3000