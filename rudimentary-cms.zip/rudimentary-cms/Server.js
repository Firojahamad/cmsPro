const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123456', 
  database: 'simple_cms2'
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.stack);
    return;
  }
  console.log('Connected to the database');
});

// Serve the index.html file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

function isValidDate(dateString) {
  const regEx = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateString.match(regEx)) return false; 
  const date = new Date(dateString);
  const timestamp = date.getTime();
  if (typeof timestamp !== 'number' || isNaN(timestamp)) return false;  
  return date.toISOString().startsWith(dateString);
}

app.post('/create-entity', (req, res) => {
  const { name, email, mobileNumber, dateOfBirth } = req.body;

  if (!isValidDate(dateOfBirth)) {
    res.status(400).json({ error: 'Invalid date format' });
    return;
  }

  db.query('INSERT INTO entities (name, email, mobile_number, date_of_birth) VALUES (?, ?, ?, ?)', [name, email, mobileNumber, dateOfBirth], (err, result) => {
    if (err) {
      console.error('Error creating entity:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.status(201).json({ message: 'Entity created successfully' });
  });
});

app.get('/entities', (req, res) => {
  db.query('SELECT * FROM entities', (err, results) => {
    if (err) {
      console.error('Error retrieving entities:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.status(200).json(results);
  });
});

app.put('/entities/:id', (req, res) => {
  const id = req.params.id;
  const { name, email, mobile_number, date_of_birth } = req.body;

  if (date_of_birth && !isValidDate(date_of_birth)) {
    res.status(400).json({ error: 'Invalid date format' });
    return;
  }

  db.query('UPDATE entities SET name = ?, email = ?, mobile_number = ?, date_of_birth = ? WHERE id = ?', [name, email, mobile_number, date_of_birth, id], (err, result) => {
    if (err) {
      console.error('Error updating entity:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.status(200).json({ message: 'Entity updated successfully' });
  });
});

app.delete('/entities/:id', (req, res) => {
  const id = req.params.id;

  db.query('DELETE FROM entities WHERE id = ?', [id], (err, result) => {
    if (err) {
      console.error('Error deleting entity:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    res.status(200).json({ message: 'Entity deleted successfully' });
  });
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
